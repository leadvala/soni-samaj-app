<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ServiceSectionPage extends Model
{
    protected $fillable = [
        'service_section_id',
        'page_id',
    ];
}
